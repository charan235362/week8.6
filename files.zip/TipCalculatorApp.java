import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Main application class: loads tip_calculator.fxml and shows the window.
 */
public class TipCalculatorApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Step 3: Load the FXML file (must be in the same folder as the compiled classes)
        Parent root = FXMLLoader.load(getClass().getResource("tip_calculator.fxml"));

        // Set the scene and show the stage
        primaryStage.setTitle("Tip Calculator");
        primaryStage.setScene(new Scene(root, 400, 380));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

/*
 * ---------------------------------------------------------------
 * PROJECT FILES (keep all three in the same folder)
 * ---------------------------------------------------------------
 *   TipCalculatorApp.java
 *   TipCalculatorController.java
 *   tip_calculator.fxml
 *
 * ---------------------------------------------------------------
 * COMPILE & RUN (command line)
 * ---------------------------------------------------------------
 * Replace PATH_TO_FX with the "lib" folder of your JavaFX SDK.
 *
 * 1. Compile into an "out" folder:
 *      javac --module-path PATH_TO_FX --add-modules javafx.controls,javafx.fxml -d out *.java
 *
 * 2. Copy the FXML file next to the compiled classes:
 *      copy tip_calculator.fxml out            (Windows)
 *      cp tip_calculator.fxml out              (Linux/Mac)
 *
 * 3. Run:
 *      java --module-path PATH_TO_FX --add-modules javafx.controls,javafx.fxml -cp out TipCalculatorApp
 *
 * (In an IDE, add the VM options:
 *      --module-path PATH_TO_FX --add-modules javafx.controls,javafx.fxml
 *  and make sure the .fxml file is on the classpath / resources.)
 *
 * ---------------------------------------------------------------
 * EXAMPLE RUNS
 * ---------------------------------------------------------------
 * Bill Amount: 50.00, Tip Percentage: 15  ->  Tip Amount: $7.50
 * Bill Amount: abc,   Tip Percentage: 15  ->  Error: Invalid input. Please enter numbers.
 * Click Reset                              ->  All fields and labels are cleared.
 */
