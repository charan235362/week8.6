import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 * Controller for tip_calculator.fxml.
 * Handles the Calculate Tip and Reset button actions.
 */
public class TipCalculatorController {

    // Step 2: Inject UI components defined in the FXML file
    @FXML
    private TextField billAmountField;

    @FXML
    private TextField tipPercentageField;

    @FXML
    private Button calculateButton;

    @FXML
    private Button resetButton;

    @FXML
    private Label tipAmountLabel;

    @FXML
    private Label errorLabel;

    // Called when the "Calculate Tip" button is clicked
    @FXML
    private void calculateTip() {
        // Clear any previous messages
        errorLabel.setText("");
        tipAmountLabel.setText("");

        try {
            // Parse bill amount and tip percentage
            double billAmount = Double.parseDouble(billAmountField.getText().trim());
            double tipPercentage = Double.parseDouble(tipPercentageField.getText().trim());

            // Negative values are not meaningful
            if (billAmount < 0 || tipPercentage < 0) {
                errorLabel.setText("Error: Values cannot be negative.");
                return;
            }

            // Calculate the tip amount
            double tipAmount = billAmount * tipPercentage / 100.0;

            // Display the result, e.g. "Tip Amount: $7.50"
            tipAmountLabel.setText(String.format("Tip Amount: $%.2f", tipAmount));

        } catch (NumberFormatException e) {
            // Non-numeric or empty input
            errorLabel.setText("Error: Invalid input. Please enter numbers.");
        }
    }

    // Called when the "Reset" button is clicked
    @FXML
    private void reset() {
        billAmountField.clear();
        tipPercentageField.clear();
        tipAmountLabel.setText("");
        errorLabel.setText("");
    }
}
